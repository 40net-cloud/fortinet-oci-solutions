# ------ Get Image Agreement 
resource "oci_core_app_catalog_listing_resource_version_agreement" "mp_image_agreement" {
  count = local.matched_package != null ? 1 : 0

  listing_id               = local.matched_package.listing_id
  listing_resource_version = local.matched_package.resource_ver
}

# ------ Accept Terms and Subscribe to the image, placing the image in a particular compartment
resource "oci_core_app_catalog_subscription" "mp_image_subscription" {
  count = local.matched_package != null && var.mp_subscription_enabled ? 1 : 0

  compartment_id           = var.compute_compartment_ocid
  eula_link                = oci_core_app_catalog_listing_resource_version_agreement.mp_image_agreement[0].eula_link
  listing_id               = local.matched_package.listing_id
  listing_resource_version = local.matched_package.resource_ver
  oracle_terms_of_use_link = oci_core_app_catalog_listing_resource_version_agreement.mp_image_agreement[0].oracle_terms_of_use_link
  signature                = oci_core_app_catalog_listing_resource_version_agreement.mp_image_agreement[0].signature
  time_retrieved           = oci_core_app_catalog_listing_resource_version_agreement.mp_image_agreement[0].time_retrieved

  timeouts {
    create = "20m"
  }
}

# ------ Gets the partner image subscription
data "oci_core_app_catalog_subscriptions" "mp_image_subscription" {
  count = local.matched_package != null ? 1 : 0

  compartment_id = var.compute_compartment_ocid
  listing_id     = local.matched_package.listing_id


  filter {
    name   = "listing_resource_version"
    values = [local.matched_package.resource_ver]
  }
}